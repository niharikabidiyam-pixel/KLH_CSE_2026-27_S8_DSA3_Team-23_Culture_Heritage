# Heritage Atlas — Cultural Heritage Information System

A professional React + Vite frontend with a Node.js + Express REST API. It demonstrates DSA-inspired record handling for cultural heritage information.

## Requirements
- Node.js 18 or newer
- VS Code with its integrated terminal
- Internet connection for Google Fonts and remote heritage photographs

## Run in VS Code terminal (Windows)

1. Extract this ZIP file.
2. Open the extracted `cultural-heritage-information-system` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Install all dependencies (run this once):

   ```bash
   npm run install:all
   ```

5. Start the backend and frontend together:

   ```bash
   npm run dev
   ```

6. Open the Vite URL shown in the terminal, usually **http://localhost:5173**.

The backend runs at `http://localhost:5000`. You can test it at `http://localhost:5000/api/health`.

## Features
- Search records by name, location, category, historical period, or description.
- Filter by category and sort alphabetically, by location, or newest first.
- Add, edit, inspect, and delete heritage records.
- Express REST API with validation and JSON-file persistence.
- Responsive layout for desktop and mobile.

## API routes
- `GET /api/health` — backend status
- `GET /api/heritage?q=&category=&sort=` — list/search/filter/sort records
- `POST /api/heritage` — add a record
- `PUT /api/heritage/:id` — update a record
- `DELETE /api/heritage/:id` — delete a record

## DSA concepts to explain in your presentation
- **Searching:** the API currently uses a linear scan across the records and searchable fields.
- **Sorting:** records are sorted by name/location using JavaScript's built-in `Array.sort()`; newest-first uses descending IDs.
- **Storage:** records are held in a JSON file and loaded into an array in memory for each API request.
- **CRUD:** Create, Read, Update, Delete operations model record management.
- **Possible extension:** implement linked-list/tree structures and compare their operation costs with array-based storage.

## Notes
- This is a college project starter, not a production-secure service. It has no authentication or role-based access yet.
- The initial image URLs are remote sample images; replace them with verified images and sources for your final submission.
- If Windows PowerShell blocks a command, use the VS Code terminal with Command Prompt or fix the local execution policy with your institution's guidance.
