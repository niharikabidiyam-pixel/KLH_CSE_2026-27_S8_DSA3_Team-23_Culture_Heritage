import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const PORT = 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataFile = path.join(__dirname, "heritage.json");

app.use(cors());
app.use(express.json());

const starterRecords = [
  { id: 1, name: "Taj Mahal", location: "Agra, Uttar Pradesh", category: "Monument", period: "Mughal Era", year: "1632–1653", description: "An ivory-white marble mausoleum commissioned by Shah Jahan, celebrated for its symmetry, gardens, and intricate craftsmanship.", image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1000&q=85", featured: true },
  { id: 2, name: "Charminar", location: "Hyderabad, Telangana", category: "Monument", period: "Qutb Shahi Era", year: "1591", description: "Hyderabad's iconic four-minaret monument, closely connected with the city's historic markets and cultural identity.", image: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1000&q=85", featured: true },
  { id: 3, name: "Hampi Group of Monuments", location: "Hampi, Karnataka", category: "Archaeological Site", period: "Vijayanagara Empire", year: "14th–16th century", description: "A vast landscape of temple complexes, royal structures, stone streets, and remarkable remains of the Vijayanagara capital.", image: "https://images.unsplash.com/photo-1600100397608-f010f1f6d6e4?auto=format&fit=crop&w=1000&q=85", featured: true },
  { id: 4, name: "Konark Sun Temple", location: "Konark, Odisha", category: "Temple", period: "Eastern Ganga Dynasty", year: "13th century", description: "A monumental temple conceived as the celestial chariot of the Sun God, known for its sculptural detail and stone wheels.", image: "https://images.unsplash.com/photo-1606293926075-69a00dbfde81?auto=format&fit=crop&w=1000&q=85", featured: false },
  { id: 5, name: "Ajanta Caves", location: "Aurangabad region, Maharashtra", category: "Cave Heritage", period: "2nd century BCE–6th century CE", year: "Ancient India", description: "Rock-cut Buddhist caves renowned for murals, sculpture, and insights into the artistic traditions of ancient India.", image: "https://images.unsplash.com/photo-1623059508789-2e6b6c4b8b4c?auto=format&fit=crop&w=1000&q=85", featured: false },
  { id: 6, name: "Qutub Minar", location: "Delhi", category: "Monument", period: "Delhi Sultanate", year: "12th–13th century", description: "A soaring red sandstone minaret surrounded by historic structures that reflect layers of Delhi's medieval past.", image: "https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1000&q=85", featured: false }
];

function readRecords() {
  try {
    if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify(starterRecords, null, 2));
    return JSON.parse(fs.readFileSync(dataFile, "utf8"));
  } catch {
    return starterRecords;
  }
}
function saveRecords(records) {
  fs.writeFileSync(dataFile, JSON.stringify(records, null, 2));
}

app.get("/api/health", (_req, res) => res.json({ status: "ok", message: "Heritage API is running" }));

app.get("/api/heritage", (req, res) => {
  let records = readRecords();
  const q = (req.query.q || "").toLowerCase().trim();
  const category = (req.query.category || "All").toLowerCase();
  if (q) records = records.filter(r => [r.name, r.location, r.category, r.period, r.description].some(v => String(v).toLowerCase().includes(q)));
  if (category !== "all") records = records.filter(r => r.category.toLowerCase() === category);
  const sort = req.query.sort || "name";
  records.sort((a, b) => sort === "newest" ? b.id - a.id : sort === "location" ? a.location.localeCompare(b.location) : a.name.localeCompare(b.name));
  res.json(records);
});

app.post("/api/heritage", (req, res) => {
  const { name, location, category, period, year, description, image } = req.body;
  if (![name, location, category, period, description].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete all required fields." });
  }
  const records = readRecords();
  const record = { id: Date.now(), name: name.trim(), location: location.trim(), category, period: period.trim(), year: (year || "Not specified").trim(), description: description.trim(), image: image?.trim() || "https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=1000&q=85", featured: false };
  records.push(record);
  saveRecords(records);
  res.status(201).json(record);
});

app.put("/api/heritage/:id", (req, res) => {
  const records = readRecords();
  const index = records.findIndex(r => String(r.id) === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Heritage record not found." });
  const required = ["name", "location", "category", "period", "description"];
  if (required.some(k => !String(req.body[k] || "").trim())) return res.status(400).json({ error: "Please complete all required fields." });
  records[index] = { ...records[index], ...req.body, id: records[index].id };
  saveRecords(records);
  res.json(records[index]);
});

app.delete("/api/heritage/:id", (req, res) => {
  const records = readRecords();
  const updated = records.filter(r => String(r.id) !== req.params.id);
  if (updated.length === records.length) return res.status(404).json({ error: "Heritage record not found." });
  saveRecords(updated);
  res.json({ success: true });
});

app.listen(PORT, () => console.log(`Heritage API running at http://localhost:${PORT}`));
