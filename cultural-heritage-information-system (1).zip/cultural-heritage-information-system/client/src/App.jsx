import { useEffect, useMemo, useState } from "react";
import { Search, ArrowUpRight, MapPin, Landmark, Menu, X, Plus, SlidersHorizontal, ArrowDownWideNarrow, Compass, ShieldCheck, Sparkles, Pencil, Trash2, ChevronRight, Leaf, BookOpen, Globe2 } from "lucide-react";

const API = "http://localhost:5000/api/heritage";
const categories = ["All", "Monument", "Temple", "Archaeological Site", "Cave Heritage"];
const blank = { name: "", location: "", category: "Monument", period: "", year: "", description: "", image: "" };

function App() {
  const [records, setRecords] = useState([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("name");
  const [active, setActive] = useState(null);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(blank);
  const [editingId, setEditingId] = useState(null);
  const [notice, setNotice] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  async function loadRecords() {
    try {
      const params = new URLSearchParams({ q: query, category, sort });
      const res = await fetch(`${API}?${params}`);
      if (!res.ok) throw new Error("Could not load records");
      setRecords(await res.json());
    } catch {
      setNotice("Backend not connected. Start the server using the terminal instructions in README.md.");
    } finally { setLoading(false); }
  }
  useEffect(() => { loadRecords(); }, [query, category, sort]);

  const featured = useMemo(() => records.filter(r => r.featured).slice(0, 3), [records]);
  const totalCategories = new Set(records.map(r => r.category)).size;

  function openAdd() { setEditingId(null); setForm(blank); setModal(true); }
  function openEdit(record) { setEditingId(record.id); setForm({ ...record }); setModal(true); }
  async function saveRecord(e) {
    e.preventDefault();
    try {
      const res = await fetch(editingId ? `${API}/${editingId}` : API, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to save record");
      setModal(false); setNotice(editingId ? "Heritage record updated." : "Heritage record added."); loadRecords();
    } catch (err) { setNotice(err.message || "Backend not connected."); }
  }
  async function deleteRecord(record) {
    if (!window.confirm(`Delete "${record.name}" from your heritage records?`)) return;
    try {
      const res = await fetch(`${API}/${record.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Unable to delete record");
      if (active?.id === record.id) setActive(null);
      setNotice("Heritage record deleted."); loadRecords();
    } catch { setNotice("Could not delete. Check that the backend is running."); }
  }
  function jumpToCollection() { document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" }); }

  return <div className="app-shell">
    <div className="topline"><span><Sparkles size={13}/> A DIGITAL ARCHIVE OF INDIA'S LIVING HISTORY</span><span className="topline-right">DOCUMENT · DISCOVER · PRESERVE <ArrowUpRight size={13}/></span></div>
    <header className="navbar">
      <a href="#" className="brand" aria-label="Heritage Atlas home"><span className="brand-mark"><Landmark size={22}/></span><span><strong>HERITAGE<span className="brand-dot">.</span></strong><small>ATLAS / INDIA</small></span></a>
      <nav className={menuOpen ? "nav-links open" : "nav-links"}>
        <a href="#discover" onClick={() => setMenuOpen(false)}>Discover</a><a href="#collection" onClick={() => setMenuOpen(false)}>Collections</a><a href="#about" onClick={() => setMenuOpen(false)}>Our mission</a>
        <button className="nav-mobile-add" onClick={openAdd}><Plus size={16}/> Add record</button>
      </nav>
      <div className="nav-actions"><button className="button button-dark button-small" onClick={openAdd}><Plus size={16}/> Add heritage</button><button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X/> : <Menu/>}</button></div>
    </header>

    <main>
      <section className="hero" id="discover">
        <div className="hero-image"></div><div className="hero-shade"></div>
        <div className="hero-content">
          <div className="eyebrow light"><span className="eyebrow-line"></span> EVERY PLACE HAS A STORY</div>
          <h1>Where history<br/>finds its <em>home.</em></h1>
          <p className="hero-copy">An evolving digital archive of India's remarkable monuments, sacred spaces, and cultural treasures.</p>
          <div className="hero-actions"><button className="button button-cream" onClick={jumpToCollection}>Explore the archive <ArrowUpRight size={17}/></button><a href="#about" className="text-link light-link">Our purpose <ChevronRight size={15}/></a></div>
          <div className="hero-note"><span className="hero-note-icon"><Compass size={17}/></span><span><strong>Rooted in the past.</strong><small>Built for the generations ahead.</small></span></div>
        </div>
        <div className="hero-side-label">CULTURE · MEMORY · IDENTITY</div>
        <div className="hero-index"><span>01</span><span className="index-line"></span><span>04</span></div>
      </section>

      <section className="stats-strip">
        <div className="stat-intro"><span className="tiny-label">THE ARCHIVE AT A GLANCE</span><strong>Stories worth<br/>keeping alive.</strong></div>
        <div className="stat"><span className="stat-icon"><Landmark size={18}/></span><div><strong>{records.length.toString().padStart(2, "0")}</strong><small>Heritage records</small></div></div>
        <div className="stat"><span className="stat-icon"><Globe2 size={18}/></span><div><strong>{totalCategories.toString().padStart(2, "0")}</strong><small>Heritage categories</small></div></div>
        <div className="stat"><span className="stat-icon"><BookOpen size={18}/></span><div><strong>01</strong><small>Shared cultural legacy</small></div></div>
      </section>

      <section className="featured-section section-wrap">
        <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"></span> HANDPICKED HERITAGE</div><h2>Landmarks of <em>legacy.</em></h2></div><button className="text-link dark-link" onClick={jumpToCollection}>View all records <ArrowUpRight size={16}/></button></div>
        <div className="feature-grid">
          {featured.length ? featured.map((r, i) => <article className={`feature-card feature-${i + 1}`} key={r.id} onClick={() => setActive(r)}>
            <div className="feature-photo" style={{ backgroundImage: `url("${r.image}")` }}><span className="photo-number">0{i + 1}</span><button className="round-arrow" aria-label={`View ${r.name}`}><ArrowUpRight size={18}/></button></div>
            <div className="feature-info"><div className="card-meta"><span>{r.category}</span><span className="meta-dot"></span><span>{r.year}</span></div><h3>{r.name}</h3><p><MapPin size={13}/>{r.location}</p></div>
          </article>) : <div className="empty-feature">Your featured collection will appear here.</div>}
        </div>
      </section>

      <section className="collection-section" id="collection">
        <div className="section-wrap collection-inner">
          <div className="section-heading collection-heading"><div><div className="eyebrow"><span className="eyebrow-line"></span> THE KNOWLEDGE LIBRARY</div><h2>Explore the <em>archive.</em></h2><p className="section-subtitle">Search through places, periods, and the stories that connect them.</p></div><div className="collection-count"><strong>{records.length.toString().padStart(2, "0")}</strong><span>RECORDS FOUND</span></div></div>
          <div className="toolbar">
            <div className="search-box"><Search size={18}/><input aria-label="Search heritage" placeholder="Search a monument, place, period..." value={query} onChange={e => setQuery(e.target.value)}/>{query && <button onClick={() => setQuery("")} aria-label="Clear search"><X size={15}/></button>}<kbd>⌕</kbd></div>
            <label className="sort-control"><ArrowDownWideNarrow size={16}/><span>Sort by</span><select value={sort} onChange={e => setSort(e.target.value)}><option value="name">Name (A–Z)</option><option value="location">Location</option><option value="newest">Recently added</option></select></label>
          </div>
          <div className="category-row"><span className="filter-label"><SlidersHorizontal size={14}/> FILTER</span>{categories.map(c => <button key={c} className={`filter-chip ${category === c ? "selected" : ""}`} onClick={() => setCategory(c)}>{c}</button>)}</div>
          {loading ? <div className="loading-state">Opening the archive…</div> : records.length ? <div className="records-grid">{records.map((r, i) => <article className="record-card" key={r.id}>
            <button className="record-image" onClick={() => setActive(r)} style={{ backgroundImage: `url("${r.image}")` }} aria-label={`View details for ${r.name}`}><span className="record-index">{String(i + 1).padStart(2, "0")}</span><span className="record-view">Explore <ArrowUpRight size={14}/></span></button>
            <div className="record-content"><div className="card-meta"><span>{r.category}</span></div><h3>{r.name}</h3><p className="record-location"><MapPin size={14}/>{r.location}</p><p className="record-description">{r.description}</p><div className="record-bottom"><span className="period-tag">{r.period}</span><div className="record-actions"><button onClick={() => openEdit(r)} aria-label="Edit record"><Pencil size={14}/></button><button onClick={() => deleteRecord(r)} aria-label="Delete record"><Trash2 size={14}/></button><button onClick={() => setActive(r)} aria-label="View record"><ArrowUpRight size={16}/></button></div></div></div>
          </article>)}</div> : <div className="empty-state"><Search size={26}/><h3>No records found</h3><p>Try another keyword or select a different category.</p><button className="button button-dark" onClick={() => { setQuery(""); setCategory("All"); }}>Clear filters</button></div>}
          <div className="collection-foot"><span>SHOWING {records.length} RECORD{records.length === 1 ? "" : "S"}</span><span>KNOWLEDGE PRESERVED, STORIES CONTINUED <Leaf size={14}/></span></div>
        </div>
      </section>

      <section className="mission-section" id="about"><div className="mission-art"><div className="mission-image"></div><div className="mission-stamp"><Landmark size={25}/><span>EST. IN<br/>CURIOSITY</span></div></div><div className="mission-copy"><div className="eyebrow light"><span className="eyebrow-line"></span> WHY THIS MATTERS</div><h2>Preserving the past.<br/>Inspiring the <em>future.</em></h2><p>Heritage is more than stone and structure. It is the knowledge, craft, and collective memory passed from one generation to the next.</p><p>This archive brings cultural information into one accessible space—making it easier to discover, document, and share the places that shape our identity.</p><div className="mission-points"><div><ShieldCheck size={18}/><span><strong>Structured knowledge</strong><small>Organised records, ready to explore.</small></span></div><div><Search size={18}/><span><strong>Discovery made simple</strong><small>Search, sort, and find information quickly.</small></span></div></div><button className="button button-cream" onClick={jumpToCollection}>Discover the collection <ArrowUpRight size={16}/></button></div></section>
    </main>

    <footer className="footer"><a href="#" className="brand footer-brand"><span className="brand-mark"><Landmark size={20}/></span><span><strong>HERITAGE<span className="brand-dot">.</span></strong><small>ATLAS / INDIA</small></span></a><p>A student project for the preservation of cultural knowledge.</p><span className="footer-copy">© 2026 HERITAGE ATLAS · MADE WITH PURPOSE</span></footer>

    {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice("")}><X size={15}/></button></div>}

    {modal && <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && setModal(false)}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-head"><div><div className="eyebrow"><span className="eyebrow-line"></span> ARCHIVE MANAGEMENT</div><h2 id="modal-title">{editingId ? "Edit heritage record" : "Add to the archive"}</h2></div><button className="modal-close" onClick={() => setModal(false)} aria-label="Close"><X/></button></div><form onSubmit={saveRecord} className="record-form">
      <label>Heritage site name *<input required value={form.name} onChange={e => setForm({...form, name:e.target.value})} placeholder="e.g. Golconda Fort"/></label>
      <label>Location *<input required value={form.location} onChange={e => setForm({...form, location:e.target.value})} placeholder="City, State"/></label>
      <div className="form-two"><label>Category *<select value={form.category} onChange={e => setForm({...form, category:e.target.value})}>{categories.filter(c => c !== "All").concat("Museum", "Artifact", "Cultural Site").map(c => <option key={c}>{c}</option>)}</select></label><label>Historical period *<input required value={form.period} onChange={e => setForm({...form, period:e.target.value})} placeholder="e.g. Kakatiya Dynasty"/></label></div>
      <label>Year / time period<input value={form.year} onChange={e => setForm({...form, year:e.target.value})} placeholder="e.g. 12th century"/></label>
      <label>Description *<textarea required rows="4" value={form.description} onChange={e => setForm({...form, description:e.target.value})} placeholder="Describe the history and cultural significance..."/></label>
      <label>Image URL <input type="url" value={form.image} onChange={e => setForm({...form, image:e.target.value})} placeholder="https://... (optional)"/></label>
      <div className="form-actions"><button type="button" className="button button-outline" onClick={() => setModal(false)}>Cancel</button><button className="button button-dark" type="submit">{editingId ? "Save changes" : "Add record"} <ArrowUpRight size={16}/></button></div>
    </form></section></div>}

    {active && <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && setActive(null)}><section className="detail-modal" role="dialog" aria-modal="true" aria-labelledby="detail-title"><div className="detail-photo" style={{backgroundImage:`url("${active.image}")`}}><button className="modal-close detail-close" onClick={() => setActive(null)} aria-label="Close"><X/></button><span className="detail-photo-label">HERITAGE ARCHIVE / INDIA</span></div><div className="detail-body"><div className="card-meta"><span>{active.category}</span><span className="meta-dot"></span><span>{active.year}</span></div><h2 id="detail-title">{active.name}</h2><p className="detail-location"><MapPin size={15}/>{active.location}</p><p className="detail-description">{active.description}</p><div className="detail-period"><span>HISTORICAL PERIOD</span><strong>{active.period}</strong></div><div className="form-actions"><button className="button button-outline" onClick={() => setActive(null)}>Close</button><button className="button button-dark" onClick={() => { const r = active; setActive(null); openEdit(r); }}><Pencil size={15}/> Edit record</button></div></div></section></div>}
  </div>;
}

export default App;
